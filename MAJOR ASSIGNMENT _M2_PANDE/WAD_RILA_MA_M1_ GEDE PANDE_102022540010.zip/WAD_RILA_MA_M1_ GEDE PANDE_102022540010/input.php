<script>
    // Mengambil data dari localStorage
    function ambilData() {
        return JSON.parse(
            localStorage.getItem("dataSupplier")
        ) || [];
    }

    // Menyimpan data ke localStorage
    function simpanData(data) {
        localStorage.setItem(
            "dataSupplier",
            JSON.stringify(data)
        );
    }

    // PROSES TAMBAH / EDIT
    document.getElementById("supplierForm")
        .addEventListener("submit", function(event) {

        event.preventDefault();

        let data = ambilData();

        const editId = document.getElementById("editId").value;

        const supplier = {
            id: editId || Date.now().toString(),
            nama: document.getElementById("nama").value.trim(),
            alamat: document.getElementById("alamat").value.trim(),
            kontak: document.getElementById("kontak").value.trim(),
            jenis: document.getElementById("jenis").value,
            status: document.getElementById("status").value
        };

        if (editId) {

            // UPDATE DATA
            data = data.map(function(item) {
                return item.id === editId ? supplier : item;
            });

            alert("Data supplier berhasil diperbarui!");

        } else {

            // TAMBAH DATA
            data.push(supplier);

            alert("Data supplier berhasil ditambahkan!");
        }

        simpanData(data);

        resetForm();
    });

    // RESET FORM
    function resetForm() {
        document.getElementById("supplierForm").reset();

        document.getElementById("editId").value = "";

        document.getElementById("judulForm").textContent =
            "Tambah Supplier Baru";

        document.getElementById("tombolSimpan").textContent =
            "Simpan Supplier";
    }

    // MODE EDIT DARI HALAMAN DISPLAY
    const params = new URLSearchParams(window.location.search);
    const idEdit = params.get("edit");

    if (idEdit) {
        const data = ambilData();

        const supplier = data.find(function(item) {
            return item.id === idEdit;
        });

        if (supplier) {
            document.getElementById("editId").value = supplier.id;
            document.getElementById("nama").value = supplier.nama;
            document.getElementById("alamat").value = supplier.alamat;
            document.getElementById("kontak").value = supplier.kontak;
            document.getElementById("jenis").value = supplier.jenis;
            document.getElementById("status").value = supplier.status;

            document.getElementById("judulForm").textContent =
                "Edit Data Supplier";

            document.getElementById("tombolSimpan").textContent =
                "Update Supplier";
        }
    }
</script>