<script>
    // MENGAMBIL DATA
    function ambilData() {
        return JSON.parse(
            localStorage.getItem("dataSupplier")
        ) || [];
    }

    // MENAMPILKAN DATA
    function tampilkanData() {

        const data = ambilData();

        const tabel = document.getElementById("tabelSupplier");

        const keyword = document.getElementById("search")
                              .value.toLowerCase();

        tabel.innerHTML = "";

        let jumlahTampil = 0;

        data.forEach(function(supplier) {

            // FILTER PENCARIAN
            if (!supplier.nama.toLowerCase().includes(keyword)) {
                return;
            }

            jumlahTampil++;

            const row = document.createElement("tr");

            // NOMOR
            const no = document.createElement("td");
            no.textContent = jumlahTampil;
            row.appendChild(no);

            // DATA SUPPLIER
            const fields = [
                supplier.nama,
                supplier.alamat,
                supplier.kontak
            ];

            fields.forEach(function(value) {
                const td = document.createElement("td");
                td.textContent = value;
                row.appendChild(td);
            });

            // JENIS BAHAN
            const jenisTd = document.createElement("td");

            const badge = document.createElement("span");

            badge.className = supplier.jenis === "Fresh"
                ? "badge badge-fresh"
                : "badge badge-dry";

            badge.textContent = supplier.jenis;

            jenisTd.appendChild(badge);
            row.appendChild(jenisTd);

            // STATUS
            const statusTd = document.createElement("td");

            const statusBadge = document.createElement("span");

            statusBadge.className =
                supplier.status === "Aktif"
                    ? "badge bg-success"
                    : "badge bg-secondary";

            statusBadge.textContent = supplier.status;

            statusTd.appendChild(statusBadge);
            row.appendChild(statusTd);

            // TOMBOL AKSI
            const aksiTd = document.createElement("td");

            // BUTTON EDIT
            const editBtn = document.createElement("button");

            editBtn.textContent = "Edit";
            editBtn.className = "btn btn-warning btn-sm me-1";

            editBtn.onclick = function() {
                window.location.href =
                    "input.html?edit=" +
                    encodeURIComponent(supplier.id);
            };

            // BUTTON HAPUS
            const hapusBtn = document.createElement("button");

            hapusBtn.textContent = "Hapus";
            hapusBtn.className = "btn btn-danger btn-sm";

            hapusBtn.onclick = function() {
                hapusData(supplier.id);
            };

            aksiTd.appendChild(editBtn);
            aksiTd.appendChild(hapusBtn);

            row.appendChild(aksiTd);

            tabel.appendChild(row);
        });

        // JIKA DATA KOSONG
        if (jumlahTampil === 0) {

            const row = document.createElement("tr");

            const td = document.createElement("td");

            td.colSpan = 7;

            td.textContent = "Data supplier tidak ditemukan.";

            td.className = "text-center text-muted";

            row.appendChild(td);

            tabel.appendChild(row);
        }

        document.getElementById("jumlahData").textContent =
            "Total supplier: " + data.length +
            " | Ditampilkan: " + jumlahTampil;
    }

    // HAPUS DATA
    function hapusData(id) {

        const yakin = confirm(
            "Apakah kamu yakin ingin menghapus data supplier ini?"
        );

        if (yakin) {

            let data = ambilData();

            data = data.filter(function(supplier) {
                return supplier.id !== id;
            });

            localStorage.setItem(
                "dataSupplier",
                JSON.stringify(data)
            );

            tampilkanData();

            alert("Data supplier berhasil dihapus!");
        }
    }

    // TAMPILKAN DATA SAAT HALAMAN DIBUKA
    tampilkanData();
</script>